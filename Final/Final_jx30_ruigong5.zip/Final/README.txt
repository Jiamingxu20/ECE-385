This program implements a PVP tank battle game, Battle City. To play the game, you need to:
	1. Complie the program.
	2. Connect to a FPGA board.
	3. Program the Device.
	4. Run NIOS II. 

Player1: 
	W
    A S D
 attack: J

Player2:
	up
    < down >
 attack: 1

Pause:
	esc