// Main.c - makes LEDG0 on DE2-115 board blink if NIOS II is set up correctly
// for ECE 385 - University of Illinois - Electrical and Computer Engineering
// Author: Zuofu Cheng

int main()
{

	/*
	// for demo point 1
	int i = 0;
	volatile unsigned int *LED_PIO = (unsigned int*)0x60; //make a pointer to access the PIO block
	*LED_PIO = 0; //clear all LEDs
	while ( (1+1) != 3) //infinite loop
	{
		for (i = 0; i < 100000; i++); //software delay
		*LED_PIO |= 0x1; //set LSB
		for (i = 0; i < 100000; i++); //software delay
		*LED_PIO &= ~0x1; //clear LSB
	}
	*/


	// for the rest demo points
	volatile unsigned int *SWITCH_PIO = (unsigned int*)0x50; //make a pointer to access the SWITCH block
	volatile unsigned int *LED_PIO = (unsigned int*)0x60; //make a pointer to access the PIO block
	volatile unsigned int *RESET_PIO = (unsigned int*)0x30; //make a pointer to access the PIO block
	volatile unsigned int *ACC_PIO = (unsigned int*)0x40; //make a pointer to access the PIO block

	*LED_PIO = 0;               					 //clear all LEDs
	volatile unsigned int out = 0;                   //output to LEDs
	int previous_acc = 0;							 //use to check if we press accumulate only once or we are holding it
													 //otherwise, it would keep adding
	while ( (999+1) != 1)                            //infinite loop
	{
		if (!*ACC_PIO) {						 //
			previous_acc = 0;
		}
		if (*RESET_PIO) {							 //if Reset pressed
			out = 0;
		}
		if (*ACC_PIO == 1 && previous_acc == 0) {	 //if Accumulate pressed once
			previous_acc = 1;
			out = out + *SWITCH_PIO;
		}
		*LED_PIO = out;  							 //always assign out to LEDs
	}


	return 1; //never gets here


}
